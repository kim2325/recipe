<?php include "header.php" ?>

    <div class="recipe-container"> <!-- recipe container -->
      <div class="image-container"> <!-- image container -->
      </div> <!-- image container -->
      <div class="info-container"> <!-- info container -->
      </div> <!-- info container -->
    </div> <!-- recipe container -->

    <div class="recipe-container"> <!-- recipe container -->
      <div class="image-container"> <!-- image container -->
      </div> <!-- image container -->
      <div class="info-container"> <!-- info container -->
      </div> <!-- info container -->
    </div> <!-- recipe container -->


    <div class="recipe-container"> <!-- recipe container -->
      <div class="image-container"> <!-- image container -->
      </div> <!-- image container -->
      <div class="info-container"> <!-- info container -->
      </div> <!-- info container -->
    </div> <!-- recipe container -->

    <?php include "footer.php" ?>
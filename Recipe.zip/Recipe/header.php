<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>Recipe Master</title>
</head>
<body>
	
	<div id="banner">
		<h1>Web Banner</h1>
	</div>

	<ul class="topnav">
		<li><a href="index.php">Home</a></li>
		<li><a href="index.php">Recipe</a></li>
		<li><a href="contact.php">Contact</a></li>
		<li><a href="#">Login</a></li>
	</ul>
